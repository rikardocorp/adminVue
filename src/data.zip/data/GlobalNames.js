export const names = {
  submit: 'Insertar',
  update: 'Actualizar',
  reset: 'Limpiar',
  cancel: 'Cancel',
  filter: 'Filtrar',
  delete: 'Eliminar',
  assign: 'Asignar'
}
